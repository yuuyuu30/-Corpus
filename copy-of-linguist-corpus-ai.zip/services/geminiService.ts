import { GoogleGenAI, Type } from "@google/genai";
import { CorpusEntry } from "../types";

const SYSTEM_INSTRUCTION = `
You are a veteran Chinese-to-Japanese translator and editor (日中翻訳者) with deep expertise in literary nuance, subculture slang (Yankee, Otaku), and period piece terminology (Samurai/Historical).

Your task is to analyze a given Japanese expression (or Chinese expression to be localized) and generate a **highly detailed** "Corpus Card" for a professional translator's database.

**CRITICAL RULE: ALL OUTPUT MUST BE IN JAPANESE** (except for Chinese terms used for reference/tags).

Follow these strict guidelines to satisfy a demanding professional user:

1.  **Meaning & Nuance**: Explain the term's specific vibe *in Japanese*. Deeply analyze the implied emotion, social hierarchy (politeness/rudeness), and literary flavor (e.g., is it hard-boiled? archaic? cutesy?).
2.  **Paraphrases (Extensive)**: Provide a **rich and varied** list of synonyms (aim for 3-5 categories with multiple words each).
    *   Don't just list dictionary synonyms. Include **creative adaptations**, **context-specific alternatives**, and **related idioms**.
    *   Categorize them clearly (e.g., "Emotional/Psychological", "Physical Action", "Slang/Casual", "Formal/Archaic", "Metaphorical").
3.  **Localization Memo (CN->JP - Deep Dive)**: **Provide 4-6 detailed bullet points.**
    *   **Source Mapping**: List specific Chinese terms/idioms (e.g., 成語, 慣用句, ネットスラング) that this Japanese phrase is a perfect match for.
    *   **Nuance Mapping**: Explain the subtle differences between the Japanese term and its Chinese counterparts.
    *   **Usage Advice**: When should a translator use this? (e.g., "Use for a cool-headed villain, not a hot-blooded hero").
    *   **Genre Context**: How does it fit in Wuxia, Modern Fantasy, or Otome games?
4.  **Examples**: Create 2 high-quality literary sentences *in Japanese* using the term.
5.  **Tags**: Generate **10-15 mixed Japanese and Chinese tags**.
    *   Include the Japanese keywords.
    *   **CRITICAL**: Include relevant **Chinese keywords/concepts** (e.g., "杀气", "眼神", "傲娇") so the user can search using Chinese.
    *   Include genre/mood tags (e.g., #Suspense, #Wuxia).

**Tone**: Professional, insightful, practical, and comprehensive.
`;

export const generateCorpusEntry = async (inputTerm: string, apiKey: string): Promise<CorpusEntry> => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please set it in settings.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  // Upgraded to Pro model to prevent hallucination/repetition bugs (e.g. "子子子...")
  const model = "gemini-3-pro-preview";

  const response = await ai.models.generateContent({
    model,
    contents: `翻訳コーパスのために、この表現を徹底的に分析し、プロの翻訳者が唸るような深い情報と豊富な類語を出力してください: "${inputTerm}"`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      // Increased budget for deeper analysis and richer content generation
      thinkingConfig: { thinkingBudget: 4096 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          term: { type: Type.STRING, description: "The expression being analyzed" },
          meaning: { type: Type.STRING, description: "Detailed meaning and nuance explanation in Japanese" },
          paraphrases: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                category: { type: Type.STRING, description: "Category of the synonym group in Japanese" },
                words: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          },
          localization_memo: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Detailed bullet points for CN->JP translation advice, including Chinese mapping."
          },
          examples: { type: Type.ARRAY, items: { type: Type.STRING } },
          tags: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Mixed Japanese and Chinese tags" }
        },
        required: ["term", "meaning", "paraphrases", "localization_memo", "examples", "tags"]
      }
    }
  });

  if (response.text) {
    return JSON.parse(response.text) as CorpusEntry;
  }
  
  throw new Error("Failed to generate corpus entry");
};