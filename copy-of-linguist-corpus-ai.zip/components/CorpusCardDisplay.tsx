import React, { useState } from 'react';
import { CorpusCard } from '../types';
import { Copy, Check, Trash2, Share2, ExternalLink } from 'lucide-react';

interface CorpusCardDisplayProps {
  card: CorpusCard;
  onDelete: (id: string) => void;
}

const CorpusCardDisplay: React.FC<CorpusCardDisplayProps> = ({ card, onDelete }) => {
  const [copied, setCopied] = useState(false);

  const formatForKeep = (c: CorpusCard): string => {
    const paraphraseText = c.paraphrases.map(p => 
      `• ${p.category}：\n  • ${p.words.join('\n  • ')}`
    ).join('\n\n');

    const memoText = c.localization_memo.map(m => `• ${m}`).join('\n');
    const exampleText = c.examples.map(e => `「${e}」`).join(' ');
    const tagsText = c.tags.map(t => `#${t}`).join(' ');

    return `${c.term}\n\n【意味・ニュアンス】\n${c.meaning}\n\n【言い換え・類語バリエーション】\n\n${paraphraseText}\n\n【ローカライズMEMO（中→日）】\n\n${memoText}\n\n【用例】\n${exampleText}\n\n【検索用タグ】\n${tagsText}`;
  };

  const handleCopy = async () => {
    const text = formatForKeep(card);
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    const text = formatForKeep(card);
    if (navigator.share) {
      try {
        await navigator.share({
          title: card.term,
          text: text,
        });
      } catch (err) {
        console.error("Share failed:", err);
      }
    } else {
      // Fallback for browsers that don't support share
      handleCopy();
    }
  };

  // Check if Web Share API is available (Mobile or supported Desktop)
  const canShare = typeof navigator !== 'undefined' && !!navigator.share;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6 hover:shadow-md transition-shadow duration-200">
      {/* Header / Term */}
      <div className="bg-slate-50 border-b border-slate-100 p-4 flex flex-col md:flex-row md:justify-between md:items-start gap-4 md:gap-0">
        <h2 className="text-xl md:text-2xl font-bold text-slate-800 serif tracking-wide break-words">
          {card.term}
        </h2>
        
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {canShare ? (
            // Mobile / Tablet: Use Native Share (Works great with Keep app)
            <button 
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold transition-colors bg-amber-100 text-amber-800 hover:bg-amber-200 border border-amber-200"
              title="Google Keepアプリなどを開いて保存"
            >
              <Share2 size={14} />
              Keepに保存 / 共有
            </button>
          ) : (
            // PC: Split into Copy + Open Link
            <>
              <button 
                onClick={handleCopy}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  copied 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
                }`}
                title="テキストをクリップボードにコピー"
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
                {copied ? 'コピー完了' : 'Keep用にコピー'}
              </button>

              <a 
                href="https://keep.google.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors bg-yellow-50 text-yellow-700 hover:bg-yellow-100 border border-yellow-200"
                title="Google Keepを新しいタブで開く"
              >
                <ExternalLink size={14} />
                Keepを開く
              </a>
            </>
          )}
          
          <div className="hidden md:block w-px h-5 bg-slate-300 mx-1"></div>

          <button 
            onClick={() => onDelete(card.id)}
            className="p-2 md:p-1.5 text-slate-400 hover:text-red-500 transition-colors ml-auto md:ml-0"
            title="削除"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      <div className="p-5 space-y-6">
        {/* Meaning */}
        <section>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">意味・ニュアンス</h3>
          <p className="text-sm md:text-base leading-relaxed text-slate-700">
            {card.meaning}
          </p>
        </section>

        {/* Paraphrases */}
        <section>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">言い換え・類語</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {card.paraphrases.map((group, idx) => (
              <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <span className="block text-xs font-semibold text-indigo-600 mb-2">{group.category}</span>
                <ul className="space-y-1">
                  {group.words.map((word, wIdx) => (
                    <li key={wIdx} className="text-sm text-slate-600 pl-2 border-l-2 border-slate-200">
                      {word}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* Localization Memo */}
        <section>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">ローカライズMEMO (中→日)</h3>
          <ul className="space-y-2">
            {card.localization_memo.map((memo, idx) => (
              <li key={idx} className="text-sm text-slate-700 flex items-start gap-2">
                <span className="text-indigo-400 mt-1.5">•</span>
                <span className="flex-1">{memo}</span>
              </li>
            ))}
          </ul>
        </section>

        {/* Examples */}
        <section>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">用例</h3>
          <div className="space-y-2">
            {card.examples.map((ex, idx) => (
              <blockquote key={idx} className="border-l-4 border-indigo-200 pl-4 py-1 italic text-slate-600 bg-slate-50/50 rounded-r text-sm font-serif">
                「{ex}」
              </blockquote>
            ))}
          </div>
        </section>

        {/* Tags */}
        <div className="pt-2 flex flex-wrap gap-2">
          {card.tags.map((tag, idx) => (
            <span key={idx} className="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-500 font-medium hover:bg-indigo-50 hover:text-indigo-600 transition-colors cursor-default">
              #{tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CorpusCardDisplay;